select d.value ||'/'||p.value||'_ora_'||s.spid||'.trc'  as trace_file_name
  from   (    select value
                     from  v$parameter
                     where name='instance_name')   p, 
             (    
                 select  value
                      from  v$parameter
                      where name ='user_dump_dest' )  d,
             ( 
                 select  spid
                      from  v$process
                      where  addr = ( 
                                        select paddr
                                           from v$session
                                          where sid = ( select sid
                                                                 from v$mystat
                                                                 where rownum=1)
                                                  )
                                              )  s  ;
